library(tidyverse)

dat <- read_csv("recode.csv") %>% 
  mutate(q_name = recode(q_name, 
                         "a_13\\n" = "a_13", 
                         "a_14\\n" = "a_14"))
